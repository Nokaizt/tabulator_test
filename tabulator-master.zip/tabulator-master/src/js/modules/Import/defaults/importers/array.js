function arrayImporter(input){
	return input;
}

export default arrayImporter;